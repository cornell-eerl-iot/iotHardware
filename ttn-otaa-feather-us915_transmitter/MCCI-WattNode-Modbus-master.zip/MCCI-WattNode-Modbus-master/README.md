# MCCI-WattNode-Modbus

Header files and code for working with the Continental Controls WattNode&reg; Modbus energy meter.

**Work in progress**

## Acknowledgements

WattNode is a registered trademark of Continental Controls. MCCI and MCCI Catena are registered trademarks of MCCI Corporation. All other trademarks are the properties of their respective owners.