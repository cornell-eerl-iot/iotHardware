var searchData=
[
  ['pass',['pass',['../class_test.html#a34a0e65e4866bfba400f564e9e76a996',1,'Test']]],
  ['peek',['peek',['../class_fake_stream.html#a8db1c0fea7e029cd3ba23cfe8676e205',1,'FakeStream']]]
];
