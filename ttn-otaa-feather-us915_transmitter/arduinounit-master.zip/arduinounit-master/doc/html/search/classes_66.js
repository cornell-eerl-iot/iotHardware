var searchData=
[
  ['fakestream',['FakeStream',['../class_fake_stream.html',1,'']]]
];
