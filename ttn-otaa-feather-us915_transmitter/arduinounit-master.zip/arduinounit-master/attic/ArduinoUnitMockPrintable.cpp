#include "ArduinoUnitMockPrintable.h"

#if !defined(ARDUINO)
Printable::~Printable() {}
#endif

